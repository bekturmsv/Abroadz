import { CreditCard } from '@material-ui/icons';
import React from 'react';
import './PaymentPage.css'

const PaymentPage = () => {
    return (
        <div className="card-div">
            <CreditCard/>
        </div>
    );
};

export default PaymentPage;
